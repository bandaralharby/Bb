Offline classroom lesson. Double-click index.html or START_LESSON.bat. Press F11 for fullscreen in Edge/Chrome. No actual payment or network connection.
